bootslider
==========

BootSlider - Is a widget that be can used as bootstrap widget

http://www.yiiframework.com/extension/bootslider
